package com.example.priyankam.listviewinsidescrollview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ScrollView;

public class NewActivity extends AppCompatActivity {
    ListView listOne;
    ListView listTwo;
    VerticalScrollview scrollView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        scrollView=(VerticalScrollview)findViewById(R.id.scroll_view);
        listOne=(ListView)findViewById(R.id.list_one);
        listTwo=(ListView)findViewById(R.id.list_two);

        // Defined Array values to show in ListView
        String[] valuesOne = new String[] { "Mercury",
                "Venus",
                "Earth",
                "Mars",
                "Jupiter",
                "Saturn",
                "Uranus",
                "Neptune"
        };
        String[] valuesTwo= new String[] { "Great Pyramid of Giza.",
                "Hanging Gardens of Babylon.",
                "Statue of Zeus at Olympia.",
                "Temple of Artemis at Ephesus.",
                "Mausoleum at Halicarnassus.",
                "Colossus of Rhodes.",
                "Lighthouse of Alexandria."

        };


        ArrayAdapter<String> adapterOne = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, valuesOne);
        ArrayAdapter<String> adapterTwo = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, valuesTwo);
        // Assign adapter to ListView
        listOne.setAdapter(adapterOne);
        listTwo.setAdapter(adapterTwo);
    }
}
