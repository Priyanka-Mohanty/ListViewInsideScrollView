package com.example.priyankam.listviewinsidescrollview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity {

    NonScrollListView listOne;
    NonScrollListView listTwo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listOne=(NonScrollListView)findViewById(R.id.list_one);
        listTwo=(NonScrollListView)findViewById(R.id.list_two);

        // Defined Array values to show in ListView
        String[] valuesOne = new String[] { "Great Pyramid of Giza.",
                "Hanging Gardens of Babylon.",
                "Statue of Zeus at Olympia.",
                "Temple of Artemis at Ephesus.",
                "Mausoleum at Halicarnassus.",
                "Colossus of Rhodes.",
                "Lighthouse of Alexandria."

        };
        String[] valuesTwo = new String[] { "Mercury",
                "Venus",
                "Earth",
                "Mars",
                "Jupiter",
                "Saturn",
                "Uranus",
                "Neptune"
        };

        ArrayAdapter<String> adapterOne = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, valuesOne);
        ArrayAdapter<String> adapterTwo = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, valuesTwo);
        // Assign adapter to ListView
        listOne.setAdapter(adapterOne);
        listTwo.setAdapter(adapterTwo);

        listOne.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(MainActivity.this,NewActivity.class);
                startActivity(intent);
            }
        });
        listTwo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(MainActivity.this,NewActivity.class);
                startActivity(intent);
            }
        });
    }
}
